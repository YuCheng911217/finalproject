﻿public class Comic
{
    public string Title { get; set; }
    public string Author { get; set; }
    public bool IsRented { get; set; }
    public bool IsReserved { get; set; }
}

    

