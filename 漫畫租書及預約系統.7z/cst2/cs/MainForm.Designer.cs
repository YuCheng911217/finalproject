﻿namespace cs
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnBookList = new Button();
            btnRent = new Button();
            btnReserve = new Button();
            btnMember = new Button();
            SuspendLayout();
            // 
            // btnBookList
            // 
            btnBookList.Location = new Point(301, 81);
            btnBookList.Name = "btnBookList";
            btnBookList.Size = new Size(94, 29);
            btnBookList.TabIndex = 0;
            btnBookList.Text = "書架";
            btnBookList.UseVisualStyleBackColor = true;
            btnBookList.Click += btnBookList_Click_1;
            // 
            // btnRent
            // 
            btnRent.Location = new Point(301, 151);
            btnRent.Name = "btnRent";
            btnRent.Size = new Size(94, 29);
            btnRent.TabIndex = 1;
            btnRent.Text = "租書";
            btnRent.UseVisualStyleBackColor = true;
            btnRent.Click += btnRent_Click_1;
            // 
            // btnReserve
            // 
            btnReserve.Location = new Point(301, 211);
            btnReserve.Name = "btnReserve";
            btnReserve.Size = new Size(94, 29);
            btnReserve.TabIndex = 2;
            btnReserve.Text = "預約";
            btnReserve.UseVisualStyleBackColor = true;
            btnReserve.Click += btnReserve_Click_1;
            // 
            // btnMember
            // 
            btnMember.Location = new Point(301, 282);
            btnMember.Name = "btnMember";
            btnMember.Size = new Size(94, 29);
            btnMember.TabIndex = 3;
            btnMember.Text = "會員";
            btnMember.UseVisualStyleBackColor = true;
            btnMember.Click += btnMember_Click_1;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(9F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnMember);
            Controls.Add(btnReserve);
            Controls.Add(btnRent);
            Controls.Add(btnBookList);
            Name = "MainForm";
            Text = "MainForm";
            Load += MainForm_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button btnBookList;
        private Button btnRent;
        private Button btnReserve;
        private Button btnMember;
    }
}