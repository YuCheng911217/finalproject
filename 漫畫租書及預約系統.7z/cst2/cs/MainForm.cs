
namespace cs
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void btnBookList_Click_1(object sender, EventArgs e)
        {
            BookListForm bookForm = new BookListForm();
            bookForm.ShowDialog();
        }

        private void btnRent_Click_1(object sender, EventArgs e)
        {
            RentForm rentForm = new RentForm();
            rentForm.Show();
        }

        private void btnReserve_Click_1(object sender, EventArgs e)
        {
            ReservationForm reserveForm = new ReservationForm();
            reserveForm.Show();
        }

        private void btnMember_Click_1(object sender, EventArgs e)
        {
            MemberForm memberForm = new MemberForm();
            memberForm.Show();
        }
    }
}

