﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using cs;

namespace cs
{
    public partial class RentForm : Form
    {
        public RentForm()
        {
            InitializeComponent();
            LoadAvailableComics();
        }

        private void LoadAvailableComics()
        {
            cmbBooks.DataSource = ComicRepository.GetAvailableComics();
            cmbBooks.DisplayMember = "Title";
        }
        private void btnRent_Click_1(object sender, EventArgs e)
        {
            Comic selected = (Comic)cmbBooks.SelectedItem;
            if (selected != null)
            {
                selected.IsRented = true;
                ComicRepository.Update(selected); // 更新狀態
                MessageBox.Show($"《{selected.Title}》已成功租借！");
                LoadAvailableComics(); // 重新載入
            }
        }
    }
}
