﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace cs
{
    public partial class BookListForm : Form
    {
        private List<Comic> comics;

        public BookListForm()
        {
            InitializeComponent();
            this.Load += BookListForm_Load;
        }

        private void BookListForm_Load(object sender, EventArgs e)
        {
            dgvComics.AutoGenerateColumns = true; // ⭐️ 啟用自動產生欄位
            LoadComics();
        }

        private void LoadComics()
        {
            comics = ComicRepository.GetAll() ?? new List<Comic>();
            dgvComics.DataSource = comics;

            // 自訂欄位顯示標題（選擇性）
            if (dgvComics.Columns.Contains("Title"))
                dgvComics.Columns["Title"].HeaderText = "標題";

            if (dgvComics.Columns.Contains("Author"))
                dgvComics.Columns["Author"].HeaderText = "作者";

            if (dgvComics.Columns.Contains("IsRented"))
                dgvComics.Columns["IsRented"].HeaderText = "租借中";

            if (dgvComics.Columns.Contains("IsReserved"))
                dgvComics.Columns["IsReserved"].HeaderText = "已預約";
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (comics == null) return;

            string keyword = txtSearch.Text.ToLower();
            var filtered = comics
                .Where(c => !string.IsNullOrEmpty(c.Title) && c.Title.ToLower().Contains(keyword))
                .ToList();

            dgvComics.DataSource = filtered;
        }

        private void dgvComics_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // 預留未來使用
        }
    }
}






