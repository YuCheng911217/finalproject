﻿using System.Collections.Generic;
using System.Linq;

public static class ComicRepository
{
    private static List<Comic> comics = new List<Comic>
    
    {
        new Comic { Title = "海賊王", Author = "尾田榮一郎", IsRented = false, IsReserved = false },
        new Comic { Title = "火影忍者", Author = "岸本齊史", IsRented = false, IsReserved = false },
        new Comic { Title = "鬼滅之刃", Author = "呼世晴", IsRented = false, IsReserved = false },
        new Comic { Title = "電鋸人", Author = "藤本樹", IsRented = false, IsReserved = false },
        new Comic { Title = "全職法師", Author = "閱文漫畫", IsRented = false, IsReserved = false },
        new Comic { Title = "七大罪", Author = "鈴木央", IsRented = false, IsReserved = false },
        new Comic { Title = "進擊的巨人", Author = "諫山創", IsRented = false, IsReserved = true }
    };

    public static List<Comic> GetAll() => comics;

    public static List<Comic> GetAvailableComics() => comics.Where(c => !c.IsRented).ToList();

    public static List<Comic> GetUnrentedComics() => comics.Where(c => !c.IsRented && !c.IsReserved).ToList();

    public static void Update(Comic updated)
    {
        var comic = comics.FirstOrDefault(c => c.Title == updated.Title);
        if (comic != null)
        {
            comic.IsRented = updated.IsRented;
            comic.IsReserved = updated.IsReserved;
        }
    }
}
