﻿using System.Collections.Generic;
using cs;

namespace cs
{
    public static class MemberRepository
    {
        private static List<Member> members = new List<Member>
        {
            new Member { Name = "小明" },
            new Member { Name = "小美" }
        };

        public static List<Member> GetAll()
        {
            return members;
        }

        public static void Add(Member member)
        {
            members.Add(member);
        }
    }
}
