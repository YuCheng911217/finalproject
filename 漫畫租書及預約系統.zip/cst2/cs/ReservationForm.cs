﻿using cs;
using System;
using System.Windows.Forms;

namespace cs
{
    public partial class ReservationForm : Form
    {
        public ReservationForm()
        {
            InitializeComponent();
            LoadUnrentedComics();
        }

        private void LoadUnrentedComics()
        {
            cmbComics.DataSource = ComicRepository.GetUnrentedComics();
            cmbComics.DisplayMember = "Title";
        }
        private void btnReserve_Click_1(object sender, EventArgs e)
        {
            Comic selected = (Comic)cmbComics.SelectedItem;
            if (selected != null)
            {
                selected.IsReserved = true;
                ComicRepository.Update(selected);
                MessageBox.Show($"《{selected.Title}》預約成功！");
                LoadUnrentedComics();
            }
        }
    }
}
