﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using cs;
using System.Xml.Linq;

namespace cs 
{
    public partial class MemberForm : Form
    {
        private List<Member> members;

        public MemberForm()
        {
            InitializeComponent();
            LoadMembers();
        }

        private void LoadMembers()
        {
            dgvMembers.DataSource = null;
            members = MemberRepository.GetAll();
            dgvMembers.DataSource = members;
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            if (!string.IsNullOrEmpty(name))
            {
                Member newMember = new Member { Name = name };
                MemberRepository.Add(newMember);
                LoadMembers();
                txtName.Clear();
               
            }
            else
            {
                MessageBox.Show("請輸入姓名");
            }
        }

        private void dgvMembers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MemberForm_Load(object sender, EventArgs e)
        {

        }
    }
}
