﻿namespace cs
{
    partial class RentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbBooks = new ComboBox();
            btnRent = new Button();
            SuspendLayout();
            // 
            // cmbBooks
            // 
            cmbBooks.FormattingEnabled = true;
            cmbBooks.Location = new Point(240, 55);
            cmbBooks.Name = "cmbBooks";
            cmbBooks.Size = new Size(151, 27);
            cmbBooks.TabIndex = 0;
            // 
            // btnRent
            // 
            btnRent.Location = new Point(269, 154);
            btnRent.Name = "btnRent";
            btnRent.Size = new Size(94, 29);
            btnRent.TabIndex = 1;
            btnRent.Text = "租借";
            btnRent.UseVisualStyleBackColor = true;
            btnRent.Click += btnRent_Click_1;
            // 
            // RentForm
            // 
            AutoScaleDimensions = new SizeF(9F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnRent);
            Controls.Add(cmbBooks);
            Name = "RentForm";
            Text = "RentForm";
            ResumeLayout(false);
        }

        #endregion

        private ComboBox cmbBooks;
        private Button btnRent;
    }
}