﻿namespace cs
{
    partial class BookListForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridView dgvComics;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtSearch = new System.Windows.Forms.TextBox();
            dgvComics = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(dgvComics)).BeginInit();
            SuspendLayout();
            // 
            // txtSearch
            // 
            txtSearch.Location = new System.Drawing.Point(30, 30);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new System.Drawing.Size(200, 27);
            txtSearch.TabIndex = 0;
            txtSearch.PlaceholderText = "搜尋書名...";
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // dgvComics
            // 
            dgvComics.AllowUserToAddRows = false;
            dgvComics.AllowUserToDeleteRows = false;
            dgvComics.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvComics.Location = new System.Drawing.Point(30, 80);
            dgvComics.Name = "dgvComics";
            dgvComics.ReadOnly = true;
            dgvComics.RowHeadersWidth = 51;
            dgvComics.RowTemplate.Height = 29;
            dgvComics.Size = new System.Drawing.Size(600, 300);
            dgvComics.TabIndex = 1;
            dgvComics.CellContentClick += dgvComics_CellContentClick;
            // 
            // BookListForm
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(700, 450);
            Controls.Add(dgvComics);
            Controls.Add(txtSearch);
            Name = "BookListForm";
            Text = "漫畫清單";
            ((System.ComponentModel.ISupportInitialize)(dgvComics)).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
