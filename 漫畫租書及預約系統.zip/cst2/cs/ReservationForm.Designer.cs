﻿namespace cs
{
    partial class ReservationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnReserve = new Button();
            cmbComics = new ComboBox();
            SuspendLayout();
            // 
            // btnReserve
            // 
            btnReserve.Location = new Point(243, 199);
            btnReserve.Name = "btnReserve";
            btnReserve.Size = new Size(94, 29);
            btnReserve.TabIndex = 0;
            btnReserve.Text = "預約";
            btnReserve.UseVisualStyleBackColor = true;
            btnReserve.Click += btnReserve_Click_1;
            // 
            // cmbComics
            // 
            cmbComics.FormattingEnabled = true;
            cmbComics.Location = new Point(243, 117);
            cmbComics.Name = "cmbComics";
            cmbComics.Size = new Size(151, 27);
            cmbComics.TabIndex = 1;
            // 
            // ReservationForm
            // 
            AutoScaleDimensions = new SizeF(9F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cmbComics);
            Controls.Add(btnReserve);
            Name = "ReservationForm";
            Text = "ReservationForm";
            ResumeLayout(false);
        }

        #endregion

        private Button btnReserve;
        private ComboBox cmbComics;
    }
}